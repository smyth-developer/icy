<?php

namespace App\Providers;

use App\Listeners\LogAuthenticationEvents;
use App\Repositories\Contracts\LocationRepositoryInterface;

use App\Repositories\Contracts\RoleRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Repositories\Contracts\SeasonRepositoryInterface;
use App\Repositories\Contracts\ProgramRepositoryInterface;
use App\Repositories\Contracts\SubjectRepositoryInterface;
use App\Repositories\Contracts\CourseRepositoryInterface;
use App\Repositories\Contracts\PermissionRepositoryInterface;

use App\Repositories\Contracts\StudentRegistrationRepositoryInterface;
use App\Repositories\Contracts\SyllabusRepositoryInterface;


use App\Repositories\Eloquent\LocationRepository;
use App\Repositories\Eloquent\RoleRepository;
use App\Repositories\Eloquent\UserRepository;
use App\Repositories\Eloquent\SeasonRepository;
use App\Repositories\Eloquent\ProgramRepository;
use App\Repositories\Eloquent\SubjectRepository;
use App\Repositories\Eloquent\CourseRepository;
use App\Repositories\Eloquent\PermissionRepository;

use App\Repositories\Eloquent\StudentRegistrationRepository;
use App\Repositories\Eloquent\SyllabusRepository;

use Illuminate\Auth\Events\Logout;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Auth\Middleware\RedirectIfAuthenticated;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
        $this->app->bind(LocationRepositoryInterface::class, LocationRepository::class);
        $this->app->bind(RoleRepositoryInterface::class, RoleRepository::class);
        $this->app->bind(SeasonRepositoryInterface::class, SeasonRepository::class);
        $this->app->bind(ProgramRepositoryInterface::class, ProgramRepository::class);
        $this->app->bind(SubjectRepositoryInterface::class, SubjectRepository::class);
        $this->app->bind(CourseRepositoryInterface::class, CourseRepository::class);
        $this->app->bind(PermissionRepositoryInterface::class, PermissionRepository::class);

        $this->app->bind(StudentRegistrationRepositoryInterface::class, StudentRegistrationRepository::class);
        $this->app->bind(SyllabusRepositoryInterface::class, SyllabusRepository::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        RedirectIfAuthenticated::redirectUsing(function () {
            return route('dashboard');
        });

        Authenticate::redirectUsing(function () {
            Session::flash('status', 'Bạn cần đăng nhập để tiếp tục');
            return route('login');
        });

        // Register authentication event listeners
        Event::subscribe(LogAuthenticationEvents::class);
    }
}
