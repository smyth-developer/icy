<?php

namespace App\Livewire\Settings;

use Livewire\Component;
use Livewire\Attributes\Title;

#[Title('Quản lý giao diện')]
class Appearance extends Component
{
    //
}
