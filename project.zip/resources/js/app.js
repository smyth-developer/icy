import Sortable from 'sortablejs';
window.Sortable = Sortable;
