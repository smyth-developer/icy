<div
    class="flex aspect-square size-8 items-center justify-center rounded-md bg-transparent dark:text-white text-pink-500 ring-1 dark:ring-white ring-pink-500  dark:bg-zinc-800 ">
    <x-app-logo-icon class="w-6 h-6" />
</div>
<div class="ms-1 grid flex-1 text-start text-sm">
    <span class="mb-0.5 truncate leading-tight font-black text-pink-500 dark:text-white">International Creative Youth</span>
</div>
