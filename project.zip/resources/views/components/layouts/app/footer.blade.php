<footer
    class="bg-zinc-50 dark:bg-zinc-900 border-t border-gray-200 dark:border-zinc-700 font-black text-center text-base text-pink-500 dark:text-white py-4">
    © {{ date('Y') }} International Creative Youth. All rights reserved.
</footer>
