<div class="relative mb-6 w-full">
    <flux:heading size="xl" level="1">Cài đặt</flux:heading>
    <flux:subheading size="lg" class="mb-6">Quản lý hồ sơ và cài đặt tài khoản</flux:subheading>
    <flux:separator variant="subtle" />
</div>
